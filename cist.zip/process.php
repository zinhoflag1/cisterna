<?php

var_dump($_POST, $_FILES);

?>